{
  "name": "minecraft-bot",
  "version": "1.0.0",
  "main": "bot.js",
  "scripts": {
    "start": "node bot.js"
  },
  "dependencies": {
    "mineflayer": "^4.8.0",
    "mineflayer-pathfinder": "^2.0.0",
    "vec3": "^0.1.7"
  }
}
